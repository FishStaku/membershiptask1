/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_admin_note_actions`; */
/* PRE_TABLE_NAME: `1621813188_wp_wc_admin_note_actions`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1621813188_wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1621813188_wp_wc_admin_note_actions` (`action_id`, `note_id`, `name`, `label`, `query`, `status`, `is_primary`, `actioned_text`) VALUES ( 
/* VALUES START */
1,
1,
'yes-please',
'Yes please!',
'https://woocommerce.us8.list-manage.com/subscribe/post?u=2c1434dc56f9506bf3c3ecd21&amp;id=13860df971&amp;SIGNUPPAGE=plugin',
'actioned',
0,
''
/* VALUES END */
), (
/* VALUES START */
2,
2,
'connect',
'Connect',
'?page=wc-addons&section=helper',
'unactioned',
0,
''
/* VALUES END */
), (
/* VALUES START */
3,
3,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/how-to-sell-online-courses-wordpress/?utm_source=inbox',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
4,
4,
'install-jp-and-wcs-plugins',
'Install plugins',
'',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
5,
5,
'learn-more',
'Learn more',
'https://docs.woocommerce.com/document/variable-product/?utm_source=inbox',
'actioned',
0,
''
/* VALUES END */
), (
/* VALUES START */
6,
6,
'test-checkout',
'Test checkout',
'http://localhost/membershiptask/',
'actioned',
0,
''
/* VALUES END */
), (
/* VALUES START */
7,
7,
'learn-more',
'Learn More',
'https://woocommerce.com/products/woocommerce-subscriptions/?utm_source=inbox',
'unactioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
8,
8,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/pre-launch-checklist-the-essentials/?utm_source=inbox',
'actioned',
0,
''
/* VALUES END */
), (
/* VALUES START */
9,
9,
'visit-the-theme-marketplace',
'Visit the theme marketplace',
'https://woocommerce.com/product-category/themes/?utm_source=inbox',
'actioned',
0,
''
/* VALUES END */
), (
/* VALUES START */
10,
10,
'affirm-insight-first-product-and-payment',
'Yes',
'',
'actioned',
0,
'Thanks for your feedback'
/* VALUES END */
), (
/* VALUES START */
11,
10,
'affirm-insight-first-product-and-payment',
'No',
'',
'actioned',
0,
'Thanks for your feedback'
/* VALUES END */
), (
/* VALUES START */
12,
11,
'first-downloadable-product-handling',
'Learn more',
'https://docs.woocommerce.com/document/digital-downloadable-product-handling/?utm_source=inbox',
'actioned',
0,
''
/* VALUES END */
), (
/* VALUES START */
165,
12,
'open_wc_paypal_payments_product_page',
'Learn more',
'https://woocommerce.com/products/woocommerce-paypal-payments/',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
166,
13,
'upgrade_now_facebook_pixel_api',
'Upgrade now',
'plugin-install.php?tab=plugin-information&plugin=&section=changelog',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
167,
14,
'learn_more_facebook_ec',
'Learn more',
'https://woocommerce.com/products/facebook/',
'unactioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
168,
15,
'set-up-concierge',
'Schedule free session',
'https://wordpress.com/me/concierge',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
169,
16,
'learn-more',
'Learn more',
'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox',
'unactioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
170,
17,
'learn-more-ecomm-unique-shopping-experience',
'Learn more',
'https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
171,
18,
'watch-the-webinar',
'Watch the webinar',
'https://youtu.be/V_2XtCOyZ7o',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
172,
19,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
173,
20,
'boost-sales-marketing-guide',
'See marketing guide',
'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-boost-sales',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
174,
21,
'grow-your-business-marketing-guide',
'See marketing guide',
'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-grow-your-business',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
175,
22,
'add-apple-pay',
'Add Apple Pay',
'/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
176,
22,
'learn-more',
'Learn more',
'https://docs.woocommerce.com/document/payments/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
177,
23,
'boost-sales-marketing-guide',
'See marketing guide',
'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-boost-sales',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
178,
24,
'grow-your-business-marketing-guide',
'See marketing guide',
'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-grow-your-business',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
179,
25,
'optimizing-the-checkout-flow',
'Learn more',
'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
180,
26,
'learn-more',
'Learn more',
'https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox',
'unactioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
181,
27,
'qualitative-feedback-from-new-users',
'Share feedback',
'https://automattic.survey.fm/wc-pay-new',
'actioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
182,
28,
'share-feedback',
'Share feedback',
'http://automattic.survey.fm/paypal-feedback',
'unactioned',
1,
''
/* VALUES END */
), (
/* VALUES START */
183,
29,
'learn-more',
'Learn about Instant Deposits eligibility',
'https://docs.woocommerce.com/document/payments/instant-deposits/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits',
'actioned',
1,
''
/* VALUES END */
);
/* QUERY END */

