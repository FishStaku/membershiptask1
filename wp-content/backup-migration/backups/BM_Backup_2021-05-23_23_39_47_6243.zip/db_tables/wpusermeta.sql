/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_usermeta`; */
/* PRE_TABLE_NAME: `1621813188_wp_usermeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1621813188_wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1621813188_wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
1,
'nickname',
'fishsticks'
/* VALUES END */
), (
/* VALUES START */
2,
1,
'first_name',
''
/* VALUES END */
), (
/* VALUES START */
3,
1,
'last_name',
''
/* VALUES END */
), (
/* VALUES START */
4,
1,
'description',
''
/* VALUES END */
), (
/* VALUES START */
5,
1,
'rich_editing',
'true'
/* VALUES END */
), (
/* VALUES START */
6,
1,
'syntax_highlighting',
'true'
/* VALUES END */
), (
/* VALUES START */
7,
1,
'comment_shortcuts',
'false'
/* VALUES END */
), (
/* VALUES START */
8,
1,
'admin_color',
'fresh'
/* VALUES END */
), (
/* VALUES START */
9,
1,
'use_ssl',
0
/* VALUES END */
), (
/* VALUES START */
10,
1,
'show_admin_bar_front',
'true'
/* VALUES END */
), (
/* VALUES START */
11,
1,
'locale',
''
/* VALUES END */
), (
/* VALUES START */
12,
1,
'wp_capabilities',
'a:1:{s:13:\"administrator\";b:1;}'
/* VALUES END */
), (
/* VALUES START */
13,
1,
'wp_user_level',
10
/* VALUES END */
), (
/* VALUES START */
14,
1,
'dismissed_wp_pointers',
'plugin_editor_notice'
/* VALUES END */
), (
/* VALUES START */
15,
1,
'show_welcome_panel',
1
/* VALUES END */
), (
/* VALUES START */
17,
1,
'wp_dashboard_quick_press_last_post_id',
4
/* VALUES END */
), (
/* VALUES START */
18,
1,
'_woocommerce_tracks_anon_id',
'woo:oTmtnzKJhSKb1eOtby/4HWH5'
/* VALUES END */
), (
/* VALUES START */
19,
1,
'last_update',
1621674238
/* VALUES END */
), (
/* VALUES START */
20,
1,
'woocommerce_admin_activity_panel_inbox_last_read',
1621674236827
/* VALUES END */
), (
/* VALUES START */
21,
1,
'woocommerce_admin_task_list_tracked_started_tasks',
'{\"appearance\":1,\"tax\":1,\"payments\":1,\"purchase\":2}'
/* VALUES END */
), (
/* VALUES START */
22,
1,
'wc_last_active',
1621728000
/* VALUES END */
), (
/* VALUES START */
23,
1,
'wp_user-settings',
'libraryContent=browse'
/* VALUES END */
), (
/* VALUES START */
24,
1,
'wp_user-settings-time',
1621666873
/* VALUES END */
), (
/* VALUES START */
25,
1,
'jetpack_tracks_anon_id',
'jetpack:oF+wDZID1GMTafGF7gBpKMnN'
/* VALUES END */
), (
/* VALUES START */
26,
1,
'meta-box-order_product',
'a:3:{s:4:\"side\";s:84:\"submitdiv,product_catdiv,tagsdiv-product_tag,postimagediv,woocommerce-product-images\";s:6:\"normal\";s:55:\"postcustom,slugdiv,postexcerpt,woocommerce-product-data\";s:8:\"advanced\";s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
27,
1,
'screen_layout_product',
2
/* VALUES END */
), (
/* VALUES START */
28,
1,
'closedpostboxes_product',
'a:0:{}'
/* VALUES END */
), (
/* VALUES START */
29,
1,
'metaboxhidden_product',
'a:2:{i:0;s:10:\"postcustom\";i:1;s:7:\"slugdiv\";}'
/* VALUES END */
), (
/* VALUES START */
30,
1,
'_woocommerce_persistent_cart_1',
'a:1:{s:4:\"cart\";a:3:{s:32:\"02e74f10e0327ad868d138f2b4fdd6f0\";a:12:{s:3:\"key\";s:32:\"02e74f10e0327ad868d138f2b4fdd6f0\";s:10:\"product_id\";i:27;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";d:8;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:80000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:80000;s:8:\"line_tax\";i:0;s:3:\"adp\";a:12:{s:12:\"original_key\";N;s:4:\"attr\";N;s:4:\"orig\";a:4:{s:20:\"initial_custom_price\";N;s:14:\"original_price\";d:10000;s:26:\"original_price_without_tax\";d:10000;s:18:\"original_price_tax\";d:0;}s:7:\"history\";a:0:{}s:8:\"discount\";a:0:{}s:9:\"new_price\";d:10000;s:29:\"free_item_replace_with_coupon\";N;s:29:\"free_item_replace_coupon_name\";N;s:8:\"currency\";a:0:{}s:9:\"gift_hash\";s:0:\"\";s:19:\"free_cart_item_hash\";s:0:\"\";s:23:\"selected_free_cart_item\";b:0;}}s:32:\"33e75ff09dd601bbe69f351039152189\";a:11:{s:3:\"key\";s:32:\"33e75ff09dd601bbe69f351039152189\";s:10:\"product_id\";i:28;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:20000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:20000;s:8:\"line_tax\";i:0;}s:32:\"c0c7c76d30bd3dcaefc96f40275bdc0a\";a:11:{s:3:\"key\";s:32:\"c0c7c76d30bd3dcaefc96f40275bdc0a\";s:10:\"product_id\";i:50;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:38250;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:38250;s:8:\"line_tax\";i:0;}}}'
/* VALUES END */
), (
/* VALUES START */
32,
1,
'_order_count',
0
/* VALUES END */
), (
/* VALUES START */
42,
1,
'session_tokens',
'a:1:{s:64:\"b14566f6a3d72c14a76ca73a1f167d86446b5fd0f8b58c21ab21b6f9cc3a6439\";a:4:{s:10:\"expiration\";i:1621985749;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:133:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36 OPR/73.0.3856.344\";s:5:\"login\";i:1621812949;}}'
/* VALUES END */
);
/* QUERY END */

