/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_termmeta`; */
/* PRE_TABLE_NAME: `1621813188_wp_termmeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1621813188_wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1621813188_wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
16,
'order',
0
/* VALUES END */
), (
/* VALUES START */
2,
16,
'display_type',
''
/* VALUES END */
), (
/* VALUES START */
3,
16,
'thumbnail_id',
25
/* VALUES END */
), (
/* VALUES START */
4,
17,
'order',
0
/* VALUES END */
), (
/* VALUES START */
5,
17,
'display_type',
''
/* VALUES END */
), (
/* VALUES START */
6,
17,
'thumbnail_id',
24
/* VALUES END */
), (
/* VALUES START */
7,
15,
'product_count_product_cat',
2
/* VALUES END */
), (
/* VALUES START */
8,
16,
'product_count_product_cat',
3
/* VALUES END */
), (
/* VALUES START */
9,
17,
'product_count_product_cat',
3
/* VALUES END */
), (
/* VALUES START */
24,
22,
'order',
0
/* VALUES END */
), (
/* VALUES START */
25,
22,
'display_type',
''
/* VALUES END */
), (
/* VALUES START */
26,
22,
'thumbnail_id',
0
/* VALUES END */
), (
/* VALUES START */
27,
17,
'_age_gate-restrict',
1
/* VALUES END */
), (
/* VALUES START */
28,
22,
'_age_gate-restrict',
1
/* VALUES END */
), (
/* VALUES START */
29,
16,
'_age_gate-restrict',
1
/* VALUES END */
);
/* QUERY END */

