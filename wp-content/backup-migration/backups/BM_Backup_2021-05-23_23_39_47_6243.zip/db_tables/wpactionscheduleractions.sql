/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_actionscheduler_actions`; */
/* PRE_TABLE_NAME: `1621813188_wp_actionscheduler_actions`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1621813188_wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id` (`claim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1621813188_wp_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES ( 
/* VALUES START */
16,
'action_scheduler/migration_hook',
'complete',
'2021-05-22 06:43:18',
'2021-05-22 08:43:18',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621665798;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621665798;}',
1,
1,
'2021-05-22 06:43:27',
'2021-05-22 08:43:27',
0,
''
/* VALUES END */
), (
/* VALUES START */
17,
'action_scheduler/migration_hook',
'complete',
'2021-05-22 06:44:27',
'2021-05-22 08:44:27',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621665867;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621665867;}',
1,
1,
'2021-05-22 06:45:26',
'2021-05-22 08:45:26',
0,
''
/* VALUES END */
), (
/* VALUES START */
18,
'woocommerce_update_marketplace_suggestions',
'complete',
'2021-05-22 06:54:00',
'2021-05-22 08:54:00',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621666440;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621666440;}',
0,
1,
'2021-05-22 06:54:44',
'2021-05-22 08:54:44',
0,
''
/* VALUES END */
), (
/* VALUES START */
19,
'woocommerce_update_marketplace_suggestions',
'complete',
'2021-05-23 06:54:44',
'2021-05-23 08:54:44',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621752884;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621752884;}',
0,
1,
'2021-05-23 06:56:35',
'2021-05-23 08:56:35',
0,
''
/* VALUES END */
), (
/* VALUES START */
20,
'action_scheduler/migration_hook',
'complete',
'2021-05-22 08:35:46',
'2021-05-22 10:35:46',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621672546;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621672546;}',
1,
1,
'2021-05-22 08:36:34',
'2021-05-22 10:36:34',
0,
''
/* VALUES END */
), (
/* VALUES START */
21,
'adjust_download_permissions',
'complete',
'2021-05-22 09:53:33',
'2021-05-22 11:53:33',
'[28]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621677213;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621677213;}',
0,
1,
'2021-05-22 09:54:02',
'2021-05-22 11:54:02',
0,
''
/* VALUES END */
), (
/* VALUES START */
22,
'adjust_download_permissions',
'complete',
'2021-05-22 09:54:30',
'2021-05-22 11:54:30',
'[28]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621677270;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621677270;}',
0,
1,
'2021-05-22 09:55:49',
'2021-05-22 11:55:49',
0,
''
/* VALUES END */
), (
/* VALUES START */
23,
'adjust_download_permissions',
'complete',
'2021-05-23 03:51:55',
'2021-05-23 05:51:55',
'[28]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621741915;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621741915;}',
0,
1,
'2021-05-23 03:52:16',
'2021-05-23 05:52:16',
0,
''
/* VALUES END */
), (
/* VALUES START */
24,
'woocommerce_update_marketplace_suggestions',
'pending',
'2021-05-24 06:56:35',
'2021-05-24 08:56:35',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621839395;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621839395;}',
0,
0,
'0000-00-00 00:00:00',
'0000-00-00 00:00:00',
0,
''
/* VALUES END */
), (
/* VALUES START */
25,
'action_scheduler/migration_hook',
'complete',
'2021-05-23 22:24:04',
'2021-05-24 00:24:04',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621808644;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621808644;}',
1,
1,
'2021-05-23 22:24:06',
'2021-05-24 00:24:06',
0,
''
/* VALUES END */
), (
/* VALUES START */
26,
'action_scheduler/migration_hook',
'complete',
'2021-05-23 23:28:14',
'2021-05-24 01:28:14',
'[]',
'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1621812494;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1621812494;}',
1,
1,
'2021-05-23 23:28:14',
'2021-05-24 01:28:14',
0,
''
/* VALUES END */
);
/* QUERY END */

