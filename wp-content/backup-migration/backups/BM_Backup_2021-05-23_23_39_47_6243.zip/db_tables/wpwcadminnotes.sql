/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_admin_notes`; */
/* PRE_TABLE_NAME: `1621813188_wp_wc_admin_notes`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1621813188_wp_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT 0,
  `layout` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1621813188_wp_wc_admin_notes` (`note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `icon`) VALUES ( 
/* VALUES START */
1,
'wc-admin-onboarding-email-marketing',
'info',
'en_US',
'Sign up for tips, product updates, and inspiration',
'We\'re here for you - get tips, product updates and inspiration straight to your email box',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-22 06:42:19',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
2,
'wc-admin-wc-helper-connection',
'info',
'en_US',
'Connect to WooCommerce.com',
'Connect to get important product notifications and updates.',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-22 06:42:19',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
3,
'wc-admin-selling-online-courses',
'marketing',
'en_US',
'Do you want to sell online courses?',
'Online courses are a great solution for any business that can teach a new skill. Since courses don’t require physical product development or shipping, they’re affordable, fast to create, and can generate passive income for years to come. In this article, we provide you more information about selling courses using WooCommerce.',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-22 06:47:44',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
4,
'wc-admin-install-jp-and-wcs-plugins',
'info',
'en_US',
'Uh oh... There was a problem during the Jetpack and WooCommerce Shipping & Tax install. Please try again.',
'We noticed that there was a problem during the Jetpack and WooCommerce Shipping &amp; Tax install. Please try again and enjoy all the advantages of having the plugins connected to your store! Sorry for the inconvenience. The \"Jetpack\" and \"WooCommerce Shipping &amp; Tax\" plugins will be installed &amp; activated for free.',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-22 06:49:12',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
5,
'wc-admin-learn-more-about-variable-products',
'info',
'en_US',
'Learn more about variable products',
'Variable products are a powerful product type that lets you offer a set of variations on a product, with control over prices, stock, image and more for each variation. They can be used for a product like a shirt, where you can offer a large, medium and small and in different colors.',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-22 07:19:05',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
6,
'wc-admin-test-checkout',
'info',
'en_US',
'Don\'t forget to test your checkout',
'Make sure that your checkout is working properly before you launch your store. Go through your checkout process in its entirety: from adding a product to your cart, choosing a shipping location, and making a payment.',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-22 07:48:40',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
7,
'wc-admin-woocommerce-subscriptions',
'marketing',
'en_US',
'Do you need more info about WooCommerce Subscriptions?',
'WooCommerce Subscriptions allows you to introduce a variety of subscriptions for physical or virtual products and services. Create product-of-the-month clubs, weekly service subscriptions or even yearly software billing packages. Add sign-up fees, offer free trials, or set expiration periods.',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-23 06:42:32',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
8,
'wc-admin-launch-checklist',
'info',
'en_US',
'Ready to launch your store?',
'To make sure you never get that sinking \"what did I forget\" feeling, we\'ve put together the essential pre-launch checklist.',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-23 06:42:32',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
9,
'wc-admin-choosing-a-theme',
'marketing',
'en_US',
'Choosing a theme?',
'Check out the themes that are compatible with WooCommerce and choose one aligned with your brand and business needs.',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-23 06:42:32',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
10,
'wc-admin-insight-first-product-and-payment',
'survey',
'en_US',
'Insight',
'More than 80% of new merchants add the first product and have at least one payment method set up during the first week.<br><br>Do you find this type of insight useful?',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-23 06:42:32',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
11,
'wc-admin-first-downloadable-product',
'info',
'en_US',
'Learn more about digital/downloadable products',
'Congrats on adding your first digital product! You can learn more about how to handle digital or downloadable products in our documentation.',
'{}',
'unactioned',
'woocommerce-admin',
'2021-05-23 06:42:32',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
12,
'paypal_ppcp_gtm_2021',
'marketing',
'en_US',
'Offer more options with the new PayPal',
'Get the latest PayPal extension for a full suite of payment methods with extensive currency and country coverage.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
13,
'facebook_pixel_api_2021',
'marketing',
'en_US',
'Improve the performance of your Facebook ads',
'Enable Facebook Pixel and Conversions API through the latest version of Facebook for WooCommerce for improved measurement and ad targeting capabilities.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
14,
'facebook_ec_2021',
'marketing',
'en_US',
'Sync your product catalog with Facebook to help boost sales',
'A single click adds all products to your Facebook Business Page shop. Product changes are automatically synced, with the flexibility to control which products are listed.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
15,
'ecomm-need-help-setting-up-your-store',
'info',
'en_US',
'Need help setting up your Store?',
'Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
16,
'woocommerce-services',
'info',
'en_US',
'WooCommerce Shipping & Tax',
'WooCommerce Shipping &amp; Tax helps get your store “ready to sell” as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
17,
'ecomm-unique-shopping-experience',
'info',
'en_US',
'For a shopping experience as unique as your customers',
'Product Add-Ons allow your customers to personalize products while they’re shopping on your online store. No more follow-up email requests—customers get what they want, before they’re done checking out. Learn more about this extension that comes included in your plan.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
18,
'wc-admin-getting-started-in-ecommerce',
'info',
'en_US',
'Getting Started in eCommerce - webinar',
'We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
19,
'your-first-product',
'info',
'en_US',
'Your first product',
'That\'s huge! You\'re well on your way to building a successful online store — now it’s time to think about how you\'ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
20,
'wc-square-apple-pay-boost-sales',
'marketing',
'en_US',
'Boost sales with Apple Pay',
'Now that you accept Apple Pay® with Square you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
21,
'wc-square-apple-pay-grow-your-business',
'marketing',
'en_US',
'Grow your business with Square and Apple Pay ',
'Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
22,
'wcpay-apple-pay-is-now-available',
'marketing',
'en_US',
'Apple Pay is now available with WooCommerce Payments!',
'Increase your conversion rate by offering a fast and secure checkout with <a href=\"https://woocommerce.com/apple-pay/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_applepay\" target=\"_blank\">Apple Pay</a>®. It’s free to get started with <a href=\"https://woocommerce.com/payments/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_applepay\" target=\"_blank\">WooCommerce Payments</a>.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
23,
'wcpay-apple-pay-boost-sales',
'marketing',
'en_US',
'Boost sales with Apple Pay',
'Now that you accept Apple Pay® with WooCommerce Payments you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
24,
'wcpay-apple-pay-grow-your-business',
'marketing',
'en_US',
'Grow your business with WooCommerce Payments and Apple Pay',
'Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
25,
'wc-admin-optimizing-the-checkout-flow',
'info',
'en_US',
'Optimizing the checkout flow',
'It\'s crucial to get your store\'s checkout as smooth as possible to avoid losing sales. Let\'s take a look at how you can optimize the checkout experience for your shoppers.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
26,
'wc-admin-first-five-things-to-customize',
'info',
'en_US',
'The first 5 things to customize in your store',
'Deciding what to start with first is tricky. To help you properly prioritize, we\'ve put together this short list of the first few things you should customize in WooCommerce.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
27,
'wc-payments-qualitative-feedback',
'info',
'en_US',
'WooCommerce Payments setup - let us know what you think',
'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
28,
'share-your-feedback-on-paypal',
'info',
'en_US',
'Share your feedback on PayPal',
'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
), (
/* VALUES START */
29,
'wcpay_instant_deposits_gtm_2021',
'marketing',
'en_US',
'Get paid within minutes – Instant Deposits for WooCommerce Payments',
'Stay flexible with immediate access to your funds when you need them – including nights, weekends, and holidays. With <a href=\"https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_instant_deposits\">WooCommerce Payments\'</a> new Instant Deposits feature, you’re able to transfer your earnings to a debit card within minutes.',
'{}',
'pending',
'woocommerce.com',
'2021-05-23 07:27:13',
'',
0,
'plain',
'',
0,
'info'
/* VALUES END */
);
/* QUERY END */

