/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_postmeta`; */
/* PRE_TABLE_NAME: `1621813188_wp_postmeta`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1621813188_wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=274 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1621813188_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES ( 
/* VALUES START */
1,
2,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
2,
3,
'_wp_page_template',
'default'
/* VALUES END */
), (
/* VALUES START */
5,
6,
'_customize_draft_post_name',
'home'
/* VALUES END */
), (
/* VALUES START */
6,
6,
'_customize_changeset_uuid',
'3368f41f-2194-4022-a764-374f553ea71b'
/* VALUES END */
), (
/* VALUES START */
7,
7,
'_customize_draft_post_name',
'blog'
/* VALUES END */
), (
/* VALUES START */
8,
7,
'_customize_changeset_uuid',
'3368f41f-2194-4022-a764-374f553ea71b'
/* VALUES END */
), (
/* VALUES START */
9,
8,
'_customize_draft_post_name',
'about'
/* VALUES END */
), (
/* VALUES START */
10,
8,
'_customize_changeset_uuid',
'3368f41f-2194-4022-a764-374f553ea71b'
/* VALUES END */
), (
/* VALUES START */
11,
9,
'_customize_draft_post_name',
'contact'
/* VALUES END */
), (
/* VALUES START */
12,
9,
'_customize_changeset_uuid',
'3368f41f-2194-4022-a764-374f553ea71b'
/* VALUES END */
), (
/* VALUES START */
15,
10,
'_customize_restore_dismissed',
1
/* VALUES END */
), (
/* VALUES START */
17,
12,
'_customize_restore_dismissed',
1
/* VALUES END */
), (
/* VALUES START */
18,
13,
'_edit_lock',
'1621665281:1'
/* VALUES END */
), (
/* VALUES START */
19,
13,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
20,
13,
'_wp_trash_meta_time',
1621665311
/* VALUES END */
), (
/* VALUES START */
21,
14,
'_edit_lock',
'1621665489:1'
/* VALUES END */
), (
/* VALUES START */
22,
14,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
23,
14,
'_wp_trash_meta_time',
1621665501
/* VALUES END */
), (
/* VALUES START */
26,
16,
'_wp_attached_file',
'woocommerce-placeholder.png'
/* VALUES END */
), (
/* VALUES START */
27,
16,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
28,
22,
'_wp_attached_file',
'2021/05/other-small.jpg'
/* VALUES END */
), (
/* VALUES START */
29,
22,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:1920;s:6:\"height\";i:1280;s:4:\"file\";s:23:\"2021/05/other-small.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
30,
22,
'_source_url',
'http://localhost/membershiptask/wp-content/plugins/woocommerce/packages/woocommerce-admin/images/onboarding/other-small.jpg'
/* VALUES END */
), (
/* VALUES START */
31,
24,
'_wp_attached_file',
'2021/05/images-1.jpeg'
/* VALUES END */
), (
/* VALUES START */
32,
24,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:570;s:6:\"height\";i:538;s:4:\"file\";s:21:\"2021/05/images-1.jpeg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
33,
25,
'_wp_attached_file',
'2021/05/images.jpeg'
/* VALUES END */
), (
/* VALUES START */
34,
25,
'_wp_attachment_metadata',
'a:5:{s:5:\"width\";i:552;s:6:\"height\";i:555;s:4:\"file\";s:19:\"2021/05/images.jpeg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'
/* VALUES END */
), (
/* VALUES START */
37,
27,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
38,
27,
'_edit_lock',
'1621812539:1'
/* VALUES END */
), (
/* VALUES START */
39,
27,
'total_sales',
0
/* VALUES END */
), (
/* VALUES START */
40,
27,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
41,
27,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
42,
27,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
43,
27,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
44,
27,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
45,
27,
'_virtual',
'yes'
/* VALUES END */
), (
/* VALUES START */
46,
27,
'_downloadable',
'yes'
/* VALUES END */
), (
/* VALUES START */
47,
27,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
48,
27,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
50,
27,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
51,
27,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
52,
27,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
53,
27,
'_product_version',
'5.3.0'
/* VALUES END */
), (
/* VALUES START */
54,
27,
'_regular_price',
10000
/* VALUES END */
), (
/* VALUES START */
55,
27,
'_price',
10000
/* VALUES END */
), (
/* VALUES START */
56,
28,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
57,
28,
'_edit_lock',
'1621812551:1'
/* VALUES END */
), (
/* VALUES START */
58,
28,
'total_sales',
0
/* VALUES END */
), (
/* VALUES START */
59,
28,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
60,
28,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
61,
28,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
62,
28,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
63,
28,
'_sold_individually',
'yes'
/* VALUES END */
), (
/* VALUES START */
64,
28,
'_virtual',
'yes'
/* VALUES END */
), (
/* VALUES START */
65,
28,
'_downloadable',
'yes'
/* VALUES END */
), (
/* VALUES START */
66,
28,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
67,
28,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
69,
28,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
70,
28,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
71,
28,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
72,
28,
'_product_version',
'5.3.0'
/* VALUES END */
), (
/* VALUES START */
75,
29,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
76,
29,
'_edit_lock',
'1621812564:1'
/* VALUES END */
), (
/* VALUES START */
77,
29,
'_regular_price',
45000
/* VALUES END */
), (
/* VALUES START */
78,
29,
'total_sales',
0
/* VALUES END */
), (
/* VALUES START */
79,
29,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
80,
29,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
81,
29,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
82,
29,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
83,
29,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
84,
29,
'_virtual',
'yes'
/* VALUES END */
), (
/* VALUES START */
85,
29,
'_downloadable',
'yes'
/* VALUES END */
), (
/* VALUES START */
86,
29,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
87,
29,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
89,
29,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
90,
29,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
91,
29,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
92,
29,
'_product_version',
'5.3.0'
/* VALUES END */
), (
/* VALUES START */
93,
29,
'_price',
45000
/* VALUES END */
), (
/* VALUES START */
94,
30,
'_edit_lock',
'1621668308:1'
/* VALUES END */
), (
/* VALUES START */
95,
30,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
96,
30,
'_wp_trash_meta_time',
1621668333
/* VALUES END */
), (
/* VALUES START */
97,
31,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
98,
31,
'_wp_trash_meta_time',
1621668417
/* VALUES END */
), (
/* VALUES START */
99,
17,
'_edit_lock',
'1621670616:1'
/* VALUES END */
), (
/* VALUES START */
100,
19,
'_edit_lock',
'1621670599:1'
/* VALUES END */
), (
/* VALUES START */
103,
19,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
105,
19,
'blacklist',
1
/* VALUES END */
), (
/* VALUES START */
106,
17,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
107,
17,
'blacklist',
1
/* VALUES END */
), (
/* VALUES START */
114,
38,
'list_type',
'products_selection'
/* VALUES END */
), (
/* VALUES START */
115,
38,
'product_list_config',
'a:5:{s:16:\"selectedProducts\";a:1:{i:0;i:49;}s:13:\"productAuthor\";s:0:\"\";s:16:\"excludedProducts\";a:0:{}s:11:\"taxRelation\";N;s:5:\"rules\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
116,
39,
'list_type',
'products_selection'
/* VALUES END */
), (
/* VALUES START */
117,
39,
'product_list_config',
'a:5:{s:16:\"selectedProducts\";a:1:{i:0;i:50;}s:13:\"productAuthor\";s:0:\"\";s:16:\"excludedProducts\";a:0:{}s:11:\"taxRelation\";N;s:5:\"rules\";a:0:{}}'
/* VALUES END */
), (
/* VALUES START */
139,
41,
'discount_start_date',
'2021-05-22 08:47:34'
/* VALUES END */
), (
/* VALUES START */
140,
41,
'discount_end_date',
'2023-12-14 00:00:00'
/* VALUES END */
), (
/* VALUES START */
141,
41,
'discount_schedules',
's:103:\"a:1:{i:0;a:2:{s:10:\"start_date\";s:19:\"2021-05-22 08:47:34\";s:8:\"end_date\";s:19:\"2023-12-14 00:00:00\";}}\";'
/* VALUES END */
), (
/* VALUES START */
142,
41,
'discount_quantityranges',
's:110:\"a:1:{i:0;a:4:{s:11:\"start_range\";s:0:\"\";s:9:\"end_range\";s:0:\"\";s:8:\"dis_type\";s:0:\"\";s:9:\"dis_value\";s:0:\"\";}}\";'
/* VALUES END */
), (
/* VALUES START */
143,
41,
'discount_variation_check',
''
/* VALUES END */
), (
/* VALUES START */
144,
41,
'discount_cartamount',
''
/* VALUES END */
), (
/* VALUES START */
145,
41,
'discount_start_time',
'00:00'
/* VALUES END */
), (
/* VALUES START */
146,
41,
'discount_end_time',
'00:00'
/* VALUES END */
), (
/* VALUES START */
147,
41,
'discount_schedule_days',
''
/* VALUES END */
), (
/* VALUES START */
148,
41,
'discount_quantity_type',
''
/* VALUES END */
), (
/* VALUES START */
149,
41,
'discount_schedule_weekday',
''
/* VALUES END */
), (
/* VALUES START */
150,
41,
'discount_table_layout',
''
/* VALUES END */
), (
/* VALUES START */
151,
41,
'discount_calc_type',
''
/* VALUES END */
), (
/* VALUES START */
152,
41,
'discount_type',
'percent_product_price'
/* VALUES END */
), (
/* VALUES START */
153,
41,
'discount_value',
10
/* VALUES END */
), (
/* VALUES START */
154,
41,
'discount_status',
1
/* VALUES END */
), (
/* VALUES START */
155,
41,
'discount_reg_customers',
''
/* VALUES END */
), (
/* VALUES START */
156,
41,
'discount_pricing_table',
''
/* VALUES END */
), (
/* VALUES START */
157,
41,
'discount_priority',
1
/* VALUES END */
), (
/* VALUES START */
158,
41,
'discount_product_list',
38
/* VALUES END */
), (
/* VALUES START */
159,
41,
'discount_config',
'a:7:{s:7:\"inc_tax\";b:0;s:5:\"label\";s:28:\"Covid-19 membership discount\";s:12:\"sequentially\";b:1;s:11:\"usage_limit\";s:0:\"\";s:15:\"disable_on_sale\";b:1;s:12:\"show_in_loop\";b:0;s:5:\"rules\";s:8:\"YTowOnt9\";}'
/* VALUES END */
), (
/* VALUES START */
160,
42,
'discount_start_date',
'2021-05-22 08:49:07'
/* VALUES END */
), (
/* VALUES START */
161,
42,
'discount_end_date',
'2027-11-26 00:00:00'
/* VALUES END */
), (
/* VALUES START */
162,
42,
'discount_schedules',
's:103:\"a:1:{i:0;a:2:{s:10:\"start_date\";s:19:\"2021-05-22 08:49:07\";s:8:\"end_date\";s:19:\"2027-11-26 00:00:00\";}}\";'
/* VALUES END */
), (
/* VALUES START */
163,
42,
'discount_quantityranges',
's:110:\"a:1:{i:0;a:4:{s:11:\"start_range\";s:0:\"\";s:9:\"end_range\";s:0:\"\";s:8:\"dis_type\";s:0:\"\";s:9:\"dis_value\";s:0:\"\";}}\";'
/* VALUES END */
), (
/* VALUES START */
164,
42,
'discount_variation_check',
''
/* VALUES END */
), (
/* VALUES START */
165,
42,
'discount_cartamount',
''
/* VALUES END */
), (
/* VALUES START */
166,
42,
'discount_start_time',
'00:00'
/* VALUES END */
), (
/* VALUES START */
167,
42,
'discount_end_time',
'00:00'
/* VALUES END */
), (
/* VALUES START */
168,
42,
'discount_schedule_days',
''
/* VALUES END */
), (
/* VALUES START */
169,
42,
'discount_quantity_type',
''
/* VALUES END */
), (
/* VALUES START */
170,
42,
'discount_schedule_weekday',
''
/* VALUES END */
), (
/* VALUES START */
171,
42,
'discount_table_layout',
''
/* VALUES END */
), (
/* VALUES START */
172,
42,
'discount_calc_type',
''
/* VALUES END */
), (
/* VALUES START */
173,
42,
'discount_type',
'percent_product_price'
/* VALUES END */
), (
/* VALUES START */
174,
42,
'discount_value',
15
/* VALUES END */
), (
/* VALUES START */
175,
42,
'discount_status',
1
/* VALUES END */
), (
/* VALUES START */
176,
42,
'discount_reg_customers',
''
/* VALUES END */
), (
/* VALUES START */
177,
42,
'discount_pricing_table',
''
/* VALUES END */
), (
/* VALUES START */
178,
42,
'discount_priority',
1
/* VALUES END */
), (
/* VALUES START */
179,
42,
'discount_product_list',
39
/* VALUES END */
), (
/* VALUES START */
180,
42,
'discount_config',
'a:7:{s:7:\"inc_tax\";b:0;s:5:\"label\";s:28:\"Covid-19 membership discount\";s:12:\"sequentially\";b:1;s:11:\"usage_limit\";s:0:\"\";s:15:\"disable_on_sale\";b:0;s:12:\"show_in_loop\";b:0;s:5:\"rules\";s:8:\"YTowOnt9\";}'
/* VALUES END */
), (
/* VALUES START */
183,
28,
'_product_attributes',
'a:1:{s:15:\"silver-discount\";a:6:{s:4:\"name\";s:15:\"Silver discount\";s:5:\"value\";s:35:\"Get a 2 year membership for 10% off\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:0;}}'
/* VALUES END */
), (
/* VALUES START */
184,
28,
'blacklist',
1
/* VALUES END */
), (
/* VALUES START */
202,
28,
'_default_attributes',
'a:1:{s:15:\"silver-discount\";s:35:\"Get a 2 year membership for 10% off\";}'
/* VALUES END */
), (
/* VALUES START */
206,
46,
'epofw_prd_opt_data',
'{\"epofw_addon_name\":\"\",\"additional_rule_data\":{\"condition\":\"product\",\"operator\":\"is_equal_to\"},\"epofw_addon_position\":\"before_add_to_cart\",\"general\":{\"1\":{\"field\":{\"status\":\"on\",\"type\":\"text\",\"required\":\"on\",\"field_restriction\":\"all\",\"value\":\"test 1\",\"placeholder\":\"test 23\",\"name\":\"epofw_field_2434919211\",\"id\":\"epofw_field_1787202810\",\"class\":\"epofw_field_1090078458||epofw_all\",\"readonly\":\"on\",\"enable_price_extra\":\"on\",\"addon_price_type\":\"fixed\",\"addon_price\":\"18000\"},\"label\":{\"title\":\"Get 10% discount for 2 years membership\",\"enable_title_extra\":\"on\",\"class\":\"epofw_label_2175066515\",\"enable_subtitle_extra\":\"on\",\"subtitle\":\"Get 10% discount for 2 years membership\",\"subtitle_class\":\"Get 10% discount for 2 years membership\"}}}}'
/* VALUES END */
), (
/* VALUES START */
207,
28,
'_regular_price',
20000
/* VALUES END */
), (
/* VALUES START */
208,
28,
'_price',
20000
/* VALUES END */
), (
/* VALUES START */
209,
49,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
210,
49,
'_edit_lock',
'1621812576:1'
/* VALUES END */
), (
/* VALUES START */
211,
49,
'_regular_price',
20000
/* VALUES END */
), (
/* VALUES START */
212,
49,
'total_sales',
0
/* VALUES END */
), (
/* VALUES START */
213,
49,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
214,
49,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
215,
49,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
216,
49,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
217,
49,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
218,
49,
'_virtual',
'yes'
/* VALUES END */
), (
/* VALUES START */
219,
49,
'_downloadable',
'yes'
/* VALUES END */
), (
/* VALUES START */
220,
49,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
221,
49,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
222,
49,
'_stock',
''
/* VALUES END */
), (
/* VALUES START */
223,
49,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
224,
49,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
225,
49,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
226,
49,
'_product_version',
'5.3.0'
/* VALUES END */
), (
/* VALUES START */
227,
49,
'_price',
20000
/* VALUES END */
), (
/* VALUES START */
228,
50,
'_edit_last',
1
/* VALUES END */
), (
/* VALUES START */
229,
50,
'_edit_lock',
'1621812591:1'
/* VALUES END */
), (
/* VALUES START */
230,
50,
'_regular_price',
45000
/* VALUES END */
), (
/* VALUES START */
231,
50,
'total_sales',
0
/* VALUES END */
), (
/* VALUES START */
232,
50,
'_tax_status',
'taxable'
/* VALUES END */
), (
/* VALUES START */
233,
50,
'_tax_class',
''
/* VALUES END */
), (
/* VALUES START */
234,
50,
'_manage_stock',
'no'
/* VALUES END */
), (
/* VALUES START */
235,
50,
'_backorders',
'no'
/* VALUES END */
), (
/* VALUES START */
236,
50,
'_sold_individually',
'no'
/* VALUES END */
), (
/* VALUES START */
237,
50,
'_virtual',
'yes'
/* VALUES END */
), (
/* VALUES START */
238,
50,
'_downloadable',
'yes'
/* VALUES END */
), (
/* VALUES START */
239,
50,
'_download_limit',
-1
/* VALUES END */
), (
/* VALUES START */
240,
50,
'_download_expiry',
-1
/* VALUES END */
), (
/* VALUES START */
241,
50,
'_stock',
''
/* VALUES END */
), (
/* VALUES START */
242,
50,
'_stock_status',
'instock'
/* VALUES END */
), (
/* VALUES START */
243,
50,
'_wc_average_rating',
0
/* VALUES END */
), (
/* VALUES START */
244,
50,
'_wc_review_count',
0
/* VALUES END */
), (
/* VALUES START */
245,
50,
'_product_version',
'5.3.0'
/* VALUES END */
), (
/* VALUES START */
246,
50,
'_price',
45000
/* VALUES END */
), (
/* VALUES START */
247,
51,
'_edit_lock',
'1621801264:1'
/* VALUES END */
), (
/* VALUES START */
248,
51,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
249,
51,
'_wp_trash_meta_time',
1621801306
/* VALUES END */
), (
/* VALUES START */
250,
29,
'_oembed_95bd89be02531a995148489d8770f62a',
'<blockquote class=\"wp-embedded-content\" data-secret=\"C5Yx5Yztng\"><a href=\"http://localhost/membershiptask/product/gold-discount/\">Gold Discount</a></blockquote><iframe class=\"wp-embedded-content\" sandbox=\"allow-scripts\" security=\"restricted\" style=\"position: absolute; clip: rect(1px, 1px, 1px, 1px);\" title=\"&#8220;Gold Discount&#8221; &#8212; Covid-19 Rescue Membership\" src=\"http://localhost/membershiptask/product/gold-discount/embed/#?secret=C5Yx5Yztng\" data-secret=\"C5Yx5Yztng\" width=\"600\" height=\"338\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>'
/* VALUES END */
), (
/* VALUES START */
251,
29,
'_oembed_time_95bd89be02531a995148489d8770f62a',
1621801645
/* VALUES END */
), (
/* VALUES START */
252,
28,
'_oembed_6309796736a7d3795831bb950bdcd8c3',
'<blockquote class=\"wp-embedded-content\" data-secret=\"xVRsdN9Bji\"><a href=\"http://localhost/membershiptask/product/silver-discount/\">Silver Discount</a></blockquote><iframe class=\"wp-embedded-content\" sandbox=\"allow-scripts\" security=\"restricted\" style=\"position: absolute; clip: rect(1px, 1px, 1px, 1px);\" title=\"&#8220;Silver Discount&#8221; &#8212; Covid-19 Rescue Membership\" src=\"http://localhost/membershiptask/product/silver-discount/embed/#?secret=xVRsdN9Bji\" data-secret=\"xVRsdN9Bji\" width=\"600\" height=\"338\" frameborder=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\"></iframe>'
/* VALUES END */
), (
/* VALUES START */
253,
28,
'_oembed_time_6309796736a7d3795831bb950bdcd8c3',
1621801814
/* VALUES END */
), (
/* VALUES START */
254,
52,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
255,
52,
'_wp_trash_meta_time',
1621801871
/* VALUES END */
), (
/* VALUES START */
256,
53,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
257,
53,
'_wp_trash_meta_time',
1621801883
/* VALUES END */
), (
/* VALUES START */
258,
54,
'_edit_lock',
'1621802030:1'
/* VALUES END */
), (
/* VALUES START */
259,
54,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
260,
54,
'_wp_trash_meta_time',
1621802036
/* VALUES END */
), (
/* VALUES START */
261,
55,
'_wp_trash_meta_status',
'publish'
/* VALUES END */
), (
/* VALUES START */
262,
55,
'_wp_trash_meta_time',
1621802114
/* VALUES END */
), (
/* VALUES START */
265,
27,
'_age_gate-restrict',
1
/* VALUES END */
), (
/* VALUES START */
269,
28,
'_age_gate-restrict',
1
/* VALUES END */
), (
/* VALUES START */
271,
29,
'_age_gate-restrict',
1
/* VALUES END */
), (
/* VALUES START */
272,
49,
'_age_gate-restrict',
1
/* VALUES END */
), (
/* VALUES START */
273,
50,
'_age_gate-restrict',
1
/* VALUES END */
);
/* QUERY END */

