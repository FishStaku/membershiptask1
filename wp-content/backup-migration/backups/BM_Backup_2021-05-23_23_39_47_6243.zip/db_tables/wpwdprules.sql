/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wdp_rules`; */
/* PRE_TABLE_NAME: `1621813188_wp_wdp_rules`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1621813188_wp_wdp_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT 0,
  `enabled` tinyint(1) DEFAULT 1,
  `exclusive` tinyint(1) DEFAULT 0,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `options` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conditions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filters` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `limits` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_adjustments` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sortable_blocks_priority` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bulk_adjustments` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_discounts` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cart_adjustments` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_products` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deleted` (`deleted`),
  KEY `enabled` (`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1621813188_wp_wdp_rules` (`id`, `deleted`, `enabled`, `exclusive`, `type`, `title`, `priority`, `options`, `additional`, `conditions`, `filters`, `limits`, `product_adjustments`, `sortable_blocks_priority`, `bulk_adjustments`, `role_discounts`, `cart_adjustments`, `get_products`) VALUES ( 
/* VALUES START */
1,
0,
1,
0,
'package',
'Silver',
0,
'a:2:{s:6:\"repeat\";s:2:\"-1\";s:8:\"apply_to\";s:8:\"appeared\";}',
'a:5:{s:10:\"is_replace\";s:2:\"on\";s:12:\"replace_name\";s:0:\"\";s:19:\"sortable_apply_mode\";s:12:\"consistently\";s:26:\"free_products_replace_name\";s:0:\"\";s:23:\"conditions_relationship\";s:3:\"and\";}',
'a:0:{}',
'a:1:{i:0;a:5:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:8:\"products\";s:10:\"limitation\";s:7:\"product\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:2:\"28\";}}}',
'a:0:{}',
'a:5:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:5:\"10.00\";}s:5:\"split\";a:1:{i:0;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:5:\"10.00\";s:17:\"split_discount_by\";s:4:\"cost\";}',
'a:2:{i:0;s:5:\"roles\";i:1;s:16:\"bulk-adjustments\";}',
'a:2:{s:4:\"type\";s:4:\"bulk\";s:13:\"table_message\";s:0:\"\";}',
'a:0:{}',
'a:0:{}',
'a:2:{s:6:\"repeat\";s:2:\"-1\";s:15:\"repeat_subtotal\";s:0:\"\";}'
/* VALUES END */
), (
/* VALUES START */
2,
0,
1,
0,
'package',
'Gold',
1,
'a:2:{s:6:\"repeat\";s:2:\"-1\";s:8:\"apply_to\";s:8:\"appeared\";}',
'a:5:{s:10:\"is_replace\";s:2:\"on\";s:12:\"replace_name\";s:0:\"\";s:19:\"sortable_apply_mode\";s:12:\"consistently\";s:26:\"free_products_replace_name\";s:0:\"\";s:23:\"conditions_relationship\";s:3:\"and\";}',
'a:0:{}',
'a:1:{i:0;a:5:{s:3:\"qty\";s:1:\"1\";s:4:\"type\";s:8:\"products\";s:10:\"limitation\";s:7:\"product\";s:6:\"method\";s:7:\"in_list\";s:5:\"value\";a:1:{i:0;s:2:\"29\";}}}',
'a:0:{}',
'a:5:{s:4:\"type\";s:5:\"total\";s:5:\"total\";a:2:{s:4:\"type\";s:20:\"discount__percentage\";s:5:\"value\";s:5:\"15.00\";}s:5:\"split\";a:1:{i:0;a:2:{s:4:\"type\";s:16:\"discount__amount\";s:5:\"value\";s:0:\"\";}}s:16:\"max_discount_sum\";s:5:\"15.00\";s:17:\"split_discount_by\";s:4:\"cost\";}',
'a:2:{i:0;s:5:\"roles\";i:1;s:16:\"bulk-adjustments\";}',
'a:2:{s:4:\"type\";s:4:\"bulk\";s:13:\"table_message\";s:0:\"\";}',
'a:0:{}',
'a:0:{}',
'a:2:{s:6:\"repeat\";s:2:\"-1\";s:15:\"repeat_subtotal\";s:0:\"\";}'
/* VALUES END */
);
/* QUERY END */

