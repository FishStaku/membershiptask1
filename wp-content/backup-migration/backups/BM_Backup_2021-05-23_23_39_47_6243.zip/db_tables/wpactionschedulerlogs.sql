/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_actionscheduler_logs`; */
/* PRE_TABLE_NAME: `1621813188_wp_actionscheduler_logs`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1621813188_wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1621813188_wp_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES ( 
/* VALUES START */
1,
16,
'action created',
'2021-05-22 06:42:18',
'2021-05-22 08:42:18'
/* VALUES END */
), (
/* VALUES START */
2,
16,
'action started via WP Cron',
'2021-05-22 06:43:27',
'2021-05-22 08:43:27'
/* VALUES END */
), (
/* VALUES START */
3,
16,
'action complete via WP Cron',
'2021-05-22 06:43:27',
'2021-05-22 08:43:27'
/* VALUES END */
), (
/* VALUES START */
4,
17,
'action created',
'2021-05-22 06:43:27',
'2021-05-22 08:43:27'
/* VALUES END */
), (
/* VALUES START */
5,
17,
'action started via WP Cron',
'2021-05-22 06:45:26',
'2021-05-22 08:45:26'
/* VALUES END */
), (
/* VALUES START */
6,
17,
'action complete via WP Cron',
'2021-05-22 06:45:26',
'2021-05-22 08:45:26'
/* VALUES END */
), (
/* VALUES START */
7,
18,
'action created',
'2021-05-22 06:54:00',
'2021-05-22 08:54:00'
/* VALUES END */
), (
/* VALUES START */
8,
18,
'action started via WP Cron',
'2021-05-22 06:54:44',
'2021-05-22 08:54:44'
/* VALUES END */
), (
/* VALUES START */
9,
19,
'action created',
'2021-05-22 06:54:44',
'2021-05-22 08:54:44'
/* VALUES END */
), (
/* VALUES START */
10,
18,
'action complete via WP Cron',
'2021-05-22 06:54:44',
'2021-05-22 08:54:44'
/* VALUES END */
), (
/* VALUES START */
11,
20,
'action created',
'2021-05-22 08:34:46',
'2021-05-22 10:34:46'
/* VALUES END */
), (
/* VALUES START */
12,
20,
'action started via WP Cron',
'2021-05-22 08:36:34',
'2021-05-22 10:36:34'
/* VALUES END */
), (
/* VALUES START */
13,
20,
'action complete via WP Cron',
'2021-05-22 08:36:34',
'2021-05-22 10:36:34'
/* VALUES END */
), (
/* VALUES START */
14,
21,
'action created',
'2021-05-22 09:53:32',
'2021-05-22 11:53:32'
/* VALUES END */
), (
/* VALUES START */
15,
21,
'action started via Async Request',
'2021-05-22 09:54:02',
'2021-05-22 11:54:02'
/* VALUES END */
), (
/* VALUES START */
16,
21,
'action complete via Async Request',
'2021-05-22 09:54:02',
'2021-05-22 11:54:02'
/* VALUES END */
), (
/* VALUES START */
17,
22,
'action created',
'2021-05-22 09:54:29',
'2021-05-22 11:54:29'
/* VALUES END */
), (
/* VALUES START */
18,
22,
'action started via WP Cron',
'2021-05-22 09:55:49',
'2021-05-22 11:55:49'
/* VALUES END */
), (
/* VALUES START */
19,
22,
'action complete via WP Cron',
'2021-05-22 09:55:49',
'2021-05-22 11:55:49'
/* VALUES END */
), (
/* VALUES START */
20,
23,
'action created',
'2021-05-23 03:51:54',
'2021-05-23 05:51:54'
/* VALUES END */
), (
/* VALUES START */
21,
23,
'action started via WP Cron',
'2021-05-23 03:52:16',
'2021-05-23 05:52:16'
/* VALUES END */
), (
/* VALUES START */
22,
23,
'action complete via WP Cron',
'2021-05-23 03:52:16',
'2021-05-23 05:52:16'
/* VALUES END */
), (
/* VALUES START */
23,
19,
'action started via WP Cron',
'2021-05-23 06:56:35',
'2021-05-23 08:56:35'
/* VALUES END */
), (
/* VALUES START */
24,
24,
'action created',
'2021-05-23 06:56:35',
'2021-05-23 08:56:35'
/* VALUES END */
), (
/* VALUES START */
25,
19,
'action complete via WP Cron',
'2021-05-23 06:56:35',
'2021-05-23 08:56:35'
/* VALUES END */
), (
/* VALUES START */
26,
25,
'action created',
'2021-05-23 22:23:04',
'2021-05-24 00:23:04'
/* VALUES END */
), (
/* VALUES START */
27,
25,
'action started via WP Cron',
'2021-05-23 22:24:06',
'2021-05-24 00:24:06'
/* VALUES END */
), (
/* VALUES START */
28,
25,
'action complete via WP Cron',
'2021-05-23 22:24:06',
'2021-05-24 00:24:06'
/* VALUES END */
), (
/* VALUES START */
29,
26,
'action created',
'2021-05-23 23:27:14',
'2021-05-24 01:27:14'
/* VALUES END */
), (
/* VALUES START */
30,
26,
'action started via WP Cron',
'2021-05-23 23:28:14',
'2021-05-24 01:28:14'
/* VALUES END */
), (
/* VALUES START */
31,
26,
'action complete via WP Cron',
'2021-05-23 23:28:14',
'2021-05-24 01:28:14'
/* VALUES END */
);
/* QUERY END */

