/* QUERY START */
SET foreign_key_checks = 0;
/* QUERY END */

/* QUERY START */
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
/* QUERY END */

/* QUERY START */
SET time_zone = '+00:00';
/* QUERY END */

/* QUERY START */
SET NAMES 'utf8';
/* QUERY END */

/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_woocommerce_sessions`; */
/* PRE_TABLE_NAME: `1621813188_wp_woocommerce_sessions`; */
/* CUSTOM VARS END */

/* QUERY START */
CREATE TABLE IF NOT EXISTS `1621813188_wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/* QUERY END */

/* QUERY START */
INSERT INTO `1621813188_wp_woocommerce_sessions` (`session_id`, `session_key`, `session_value`, `session_expiry`) VALUES ( 
/* VALUES START */
55,
'7f7a5cb6cff077be3aee01b8abb47f48',
'a:1:{s:8:\"customer\";s:739:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2021-05-22T11:03:58+02:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:2:\"WC\";s:7:\"country\";s:2:\"ZA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:2:\"WC\";s:16:\"shipping_country\";s:2:\"ZA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:21:\"fishstickzy@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}',
1621841607
/* VALUES END */
), (
/* VALUES START */
82,
'50ee077d2b9bf0228e3c04cda7765d5e',
'a:1:{s:8:\"customer\";s:739:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2021-05-22T11:03:58+02:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:2:\"WC\";s:7:\"country\";s:2:\"ZA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:2:\"WC\";s:16:\"shipping_country\";s:2:\"ZA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:21:\"fishstickzy@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}',
1621914063
/* VALUES END */
), (
/* VALUES START */
84,
'd35556fb79808627c07a9f00a8a6c3d0',
'a:1:{s:8:\"customer\";s:739:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2021-05-22T11:03:58+02:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:2:\"WC\";s:7:\"country\";s:2:\"ZA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:2:\"WC\";s:16:\"shipping_country\";s:2:\"ZA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:21:\"fishstickzy@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}',
1621975315
/* VALUES END */
), (
/* VALUES START */
86,
'6de09b6593daf74941917634cb92e066',
'a:1:{s:8:\"customer\";s:739:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2021-05-22T11:03:58+02:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:2:\"WC\";s:7:\"country\";s:2:\"ZA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:2:\"WC\";s:16:\"shipping_country\";s:2:\"ZA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:21:\"fishstickzy@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}',
1621975572
/* VALUES END */
), (
/* VALUES START */
88,
'6aa416b6857e85ef1f4052453ed875b1',
'a:1:{s:8:\"customer\";s:739:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2021-05-22T11:03:58+02:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:2:\"WC\";s:7:\"country\";s:2:\"ZA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:2:\"WC\";s:16:\"shipping_country\";s:2:\"ZA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:21:\"fishstickzy@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}',
1621975694
/* VALUES END */
), (
/* VALUES START */
97,
'56f5635419fb5064861be608f3d108b9',
'a:1:{s:8:\"customer\";s:739:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2021-05-22T11:03:58+02:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:2:\"WC\";s:7:\"country\";s:2:\"ZA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:2:\"WC\";s:16:\"shipping_country\";s:2:\"ZA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:21:\"fishstickzy@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}',
1621985292
/* VALUES END */
), (
/* VALUES START */
98,
1,
'a:8:{s:4:\"cart\";s:1693:\"a:3:{s:32:\"02e74f10e0327ad868d138f2b4fdd6f0\";a:12:{s:3:\"key\";s:32:\"02e74f10e0327ad868d138f2b4fdd6f0\";s:10:\"product_id\";i:27;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";d:8;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:80000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:80000;s:8:\"line_tax\";i:0;s:3:\"adp\";a:12:{s:12:\"original_key\";N;s:4:\"attr\";N;s:4:\"orig\";a:4:{s:20:\"initial_custom_price\";N;s:14:\"original_price\";d:10000;s:26:\"original_price_without_tax\";d:10000;s:18:\"original_price_tax\";d:0;}s:7:\"history\";a:0:{}s:8:\"discount\";a:0:{}s:9:\"new_price\";d:10000;s:29:\"free_item_replace_with_coupon\";N;s:29:\"free_item_replace_coupon_name\";N;s:8:\"currency\";a:0:{}s:9:\"gift_hash\";s:0:\"\";s:19:\"free_cart_item_hash\";s:0:\"\";s:23:\"selected_free_cart_item\";b:0;}}s:32:\"33e75ff09dd601bbe69f351039152189\";a:11:{s:3:\"key\";s:32:\"33e75ff09dd601bbe69f351039152189\";s:10:\"product_id\";i:28;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:20000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:20000;s:8:\"line_tax\";i:0;}s:32:\"c0c7c76d30bd3dcaefc96f40275bdc0a\";a:11:{s:3:\"key\";s:32:\"c0c7c76d30bd3dcaefc96f40275bdc0a\";s:10:\"product_id\";i:50;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:38250;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:38250;s:8:\"line_tax\";i:0;}}\";s:11:\"cart_totals\";s:417:\"a:15:{s:8:\"subtotal\";s:9:\"138250.00\";s:12:\"subtotal_tax\";d:0;s:14:\"shipping_total\";s:4:\"0.00\";s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";s:9:\"138250.00\";s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";s:4:\"0.00\";s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";s:9:\"138250.00\";s:9:\"total_tax\";d:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"wdp_cart\";s:1864:\"a:3:{s:32:\"02e74f10e0327ad868d138f2b4fdd6f0\";a:13:{s:3:\"key\";s:32:\"02e74f10e0327ad868d138f2b4fdd6f0\";s:10:\"product_id\";i:27;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";d:8;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:80000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:80000;s:8:\"line_tax\";i:0;s:3:\"adp\";a:12:{s:12:\"original_key\";N;s:4:\"attr\";N;s:4:\"orig\";a:4:{s:20:\"initial_custom_price\";N;s:14:\"original_price\";d:10000;s:26:\"original_price_without_tax\";d:10000;s:18:\"original_price_tax\";d:0;}s:7:\"history\";a:0:{}s:8:\"discount\";a:0:{}s:9:\"new_price\";d:10000;s:29:\"free_item_replace_with_coupon\";N;s:29:\"free_item_replace_coupon_name\";N;s:8:\"currency\";a:0:{}s:9:\"gift_hash\";s:0:\"\";s:19:\"free_cart_item_hash\";s:0:\"\";s:23:\"selected_free_cart_item\";b:0;}s:4:\"data\";O:17:\"WC_Product_Simple\":1:{s:5:\"\0*\0id\";i:27;}}s:32:\"33e75ff09dd601bbe69f351039152189\";a:12:{s:3:\"key\";s:32:\"33e75ff09dd601bbe69f351039152189\";s:10:\"product_id\";i:28;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:20000;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:20000;s:8:\"line_tax\";i:0;s:4:\"data\";O:17:\"WC_Product_Simple\":1:{s:5:\"\0*\0id\";i:28;}}s:32:\"c0c7c76d30bd3dcaefc96f40275bdc0a\";a:12:{s:3:\"key\";s:32:\"c0c7c76d30bd3dcaefc96f40275bdc0a\";s:10:\"product_id\";i:50;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:38250;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:38250;s:8:\"line_tax\";i:0;s:4:\"data\";O:17:\"WC_Product_Simple\":1:{s:5:\"\0*\0id\";i:50;}}}\";s:8:\"customer\";s:739:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2021-05-22T11:03:58+02:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:2:\"WC\";s:7:\"country\";s:2:\"ZA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:2:\"WC\";s:16:\"shipping_country\";s:2:\"ZA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:21:\"fishstickzy@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}',
1621985749
/* VALUES END */
);
/* QUERY END */

